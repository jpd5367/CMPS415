Name and CLID:Joseph DeHart jpd5367
Assignment: Project 1 Triangle scan conversion with color interpolation
Specify CMPS 415 or CSCE 515: CMPS 415
--
Has anyone helped you with this assignment: No
If yes, identify them and describe the level of help: n/a
Did you help anyone else with this assignment: No
If yes, identify them and describe the level of help:n/a
Have you incorporated anything from outside sources (web sites, books, previous semesters, etc?): No, only lecture material and provided examples (i.e. mouse clicks and blue line code examples)
If yes, specify the source and level of similarity:n/a
(NOTE: There will be a point reduction if you exceed standards of �Academic Integrity� stated in the syllabus. But, if described accurately above, there will be no further disciplinary action.)
--
Compiler:Visual Studios 2013 c++ compiler
Operating System: Windows 10
List versions used for freeglut, GLEW, and GMTL, if different than requested versions:Same as suggested.
List any other nonstandard libraries used:
(NOTE: Your submission must work on a supported configuration.)

--

If compiling requires anything beyond typing "make" or selecting "build", detail it below: 


If the program supports any interaction, options, or parameters, give details below: