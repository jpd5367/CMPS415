Name and CLID:Joseph DeHart jpd5367
Assignment: Project 2 basic 3D rendering
Specify CMPS 415 or CSCE 515: CMPS 415
--
Has anyone helped you with this assignment: No
If yes, identify them and describe the level of help: n/a
Did you help anyone else with this assignment: No
If yes, identify them and describe the level of help:n/a
Have you incorporated anything from outside sources (web sites, books, previous semesters, etc?): No, only lecture material and provided examples (i.e. box example code, textbook, glut docs)
If yes, specify the source and level of similarity:n/a
(NOTE: There will be a point reduction if you exceed standards of �Academic Integrity� stated in the syllabus. But, if described accurately above, there will be no further disciplinary action.)
--
Compiler:Visual Studios 2013 c++ compiler
Operating System: Windows 10
List versions used for freeglut, GLEW, and GMTL, if different than requested versions:Same as suggested.
List any other nonstandard libraries used:
(NOTE: Your submission must work on a supported configuration.)

If compiling requires anything beyond typing "make" or selecting "build", detail it below: 

If the program supports any interaction, options, or parameters, give details below:
Following KeyStrokes have the corresponding effect on the scene/object: 
'q': exit(EXIT_SUCCESS)
'a': RotatePosYTipWorld
'b': ScaleUpXTipXLocal
'c': ScaleDownXTipXLocal
'd': RotatePhalangePosXLocal
'e': RotatePhalangeNegXLocal
'f': RotatePhalangePosYLocal
'g': RotatePhalangeNegYLocal
'h': ScaleUpPhalangeLocal
'i': ScaleDownPhalangeLocal
'j': TranslatePosYPalmLocal
'k': TranslateNegYPalmlocal
'l': TranslatePosXPalmWorld
'm': TranslateNegXPalmWorld
'n': RotatePosXPalmLocal
'o': RotatePosYPalmLocal
'p': RotatePosZPalmLocal
'r': RotatePosXPalmWorld
's': RotatePosYPalmWorld
't': RotatePosZPalmWorld